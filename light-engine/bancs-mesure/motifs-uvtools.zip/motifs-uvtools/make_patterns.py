#!/usr/bin/env python3
"""Génère les motifs d'écran pour les bancs de mesure (A à E) à la résolution native de l'écran.
Generates the screen test patterns for the measurement benches (A to E) at the native screen resolution.
生成测量台（A 至 E）所需的屏幕测试图案（按屏幕原生分辨率）。

Usage / 用法 :
    python make_patterns.py --width 7680 --height 4320 --pitch 34 --out motifs
    python make_patterns.py --width 5760 --height 3600 --pitch 34.4 --out motifs --flip-x

Options :
    --width, --height   résolution de l'écran en pixels / screen resolution in pixels
    --pitch             pas des pixels en µm / pixel pitch in µm
    --flip-x, --flip-y  miroir (certaines imprimantes affichent l'image inversée) / mirror
    --invert            inverse noir et blanc / swap black and white

Dépendance / Requires : Pillow  (pip install pillow)
Chaque image est en niveaux de gris 8 bits, uniquement 0 (noir) et 255 (blanc), sans lissage.
"""
import argparse, csv, os, sys
from PIL import Image, ImageDraw

DIGITS = {
 '0': ["01110", "10001", "10011", "10101", "11001", "10001", "01110"],
 '1': ["00100", "01100", "00100", "00100", "00100", "00100", "01110"],
 '2': ["01110", "10001", "00001", "00010", "00100", "01000", "11111"],
 '3': ["11110", "00001", "00001", "01110", "00001", "00001", "11110"],
 '4': ["00010", "00110", "01010", "10010", "11111", "00010", "00010"],
 '5': ["11111", "10000", "11110", "00001", "00001", "10001", "01110"],
 '6': ["00110", "01000", "10000", "11110", "10001", "10001", "01110"],
}


class Canvas:
    def __init__(self, w, h, pitch):
        self.w, self.h, self.pitch = w, h, pitch
        self.img = Image.new('L', (w, h), 0)
        self.d = ImageDraw.Draw(self.img)

    def mm(self, v):                      # millimètres -> pixels
        return int(round(v * 1000.0 / self.pitch))

    def rect(self, x, y, w, h, v=255):    # w, h en pixels, coin haut-gauche
        if w > 0 and h > 0:
            self.d.rectangle([x, y, x + w - 1, y + h - 1], fill=v)

    def square_c(self, cx, cy, n, v=255):  # carré de n pixels centré sur (cx, cy)
        x0, y0 = int(cx - n // 2), int(cy - n // 2)
        self.rect(x0, y0, n, n, v)

    def digit(self, ch, x, y, cell):       # chiffre 5 x 7, 'cell' pixels par case
        for j, row in enumerate(DIGITS[ch]):
            for i, c in enumerate(row):
                if c == '1':
                    self.rect(x + i * cell, y + j * cell, cell, cell)

    def digits(self, s, x, y, cell):
        for k, ch in enumerate(s):
            self.digit(ch, x + k * 6 * cell, y, cell)


def finish(cv, flip_x, flip_y, invert):
    img = cv.img
    if flip_x:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
    if flip_y:
        img = img.transpose(Image.FLIP_TOP_BOTTOM)
    if invert:
        img = img.point(lambda p: 255 - p)
    return img


def pattern_grid(W, H, step=10):
    row_on = bytearray(W)
    row_on[::step] = b'\xff' * len(range(0, W, step))
    zero = bytes(W)
    data = b''.join(bytes(row_on) if y % step == 0 else zero for y in range(H))
    return Image.frombytes('L', (W, H), data)


def plate(cv, W, H):
    """Plaque d'essai 100 x 60 mm pour le banc E."""
    mm = cv.mm
    ox, oy = W // 2 - mm(50), H // 2 - mm(30)
    if ox < 0 or oy < 0:
        sys.exit("La plaque de 100 x 60 mm ne tient pas sur cet écran avec ce pas.")
    X = lambda v: ox + mm(v)
    Y = lambda v: oy + mm(v)
    t = max(2, mm(1.0))                                   # cadre de 1 mm
    cv.rect(ox, oy, mm(100), t)
    cv.rect(ox, oy + mm(60) - t, mm(100), t)
    cv.rect(ox, oy, t, mm(60))
    cv.rect(ox + mm(100) - t, oy, t, mm(60))
    cv.d.polygon([(ox + t, oy + t), (ox + t + mm(6), oy + t), (ox + t, oy + t + mm(6))], fill=255)   # repère d'orientation
    for (cx, cy) in [(5, 55), (95, 55), (95, 5)]:                                                     # repères en croix
        cv.rect(X(cx) - mm(2), Y(cy) - 1, mm(4), 2)
        cv.rect(X(cx) - 1, Y(cy) - mm(2), 2, mm(4))
    cell = max(2, mm(0.5))                                                      # taille d'une case de chiffre
    # L : lignes isolées de 1, 2, 3, 4 et 6 pixels (verticales, puis horizontales)
    for k, wpx in enumerate([1, 2, 3, 4, 6]):
        cx = X(10 + 4 * k)
        cv.rect(cx, Y(12), wpx, mm(8))
        cv.digits(str(wpx), cx + wpx // 2 - (5 * cell) // 2, Y(6), cell)
        cy = Y(26 + 5 * k)
        cv.rect(X(12), cy, mm(8), wpx)
        cv.digits(str(wpx), X(6), cy + wpx // 2 - (7 * cell) // 2, cell)
    # G : paires de lignes de 8 pixels séparées de 1 à 6 pixels
    for k, g in enumerate([1, 2, 3, 4, 5, 6]):
        x = X(36 + 4 * k)
        cv.rect(x, Y(12), 8, mm(8))
        cv.rect(x + 8 + g, Y(12), 8, mm(8))
        cv.digits(str(g), x + (16 + g) // 2 - (5 * cell) // 2, Y(6), cell)
    # S : quatre carrés de 8 x 8 mm
    for (sx, sy) in [(64, 10), (74, 10), (64, 20), (74, 20)]:
        cv.rect(X(sx), Y(sy), mm(8), mm(8))
    # R : disque de 20 mm et barre de 50 x 3 mm
    r = mm(10)
    cv.d.ellipse([X(70) - r, Y(43) - r, X(70) + r - 1, Y(43) + r - 1], fill=255)
    cv.rect(X(28), Y(54), mm(50), mm(3))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--width', type=int, default=7680)
    ap.add_argument('--height', type=int, default=4320)
    ap.add_argument('--pitch', type=float, default=34.0)
    ap.add_argument('--out', default='motifs')
    ap.add_argument('--flip-x', action='store_true')
    ap.add_argument('--flip-y', action='store_true')
    ap.add_argument('--invert', action='store_true')
    a = ap.parse_args()
    W, H, p = a.width, a.height, a.pitch
    os.makedirs(a.out, exist_ok=True)
    rows = []

    def save(name, bench, desc, img):
        path = os.path.join(a.out, name + '.png')
        img.save(path, optimize=True)
        rows.append([name + '.png', bench, desc])
        print('ok', name + '.png')

    def new():
        return Canvas(W, H, p)

    # --- Banc A ---
    save('A1_reseau_1px_pas10', 'A', 'un pixel blanc tous les 10 pixels (pas, ouverture, uniformité du pas)', pattern_grid(W, H, 10))
    cv = new(); cv.rect(W // 2, 0, 1, H); cv.rect(0, H // 2, W, 1)
    save('A2_traits_1px', 'A', 'une ligne verticale et une horizontale de 1 pixel au centre', finish(cv, a.flip_x, a.flip_y, a.invert))
    cv = new()
    for k, n in enumerate([1, 2, 3, 5, 7]):
        cv.square_c(W // 2 + (k - 2) * 80, H // 2, n)
    save('A3_blocs_1-2-3-5-7px', 'A', 'carrés de 1, 2, 3, 5 et 7 pixels alignés au centre, espacés de 80 pixels', finish(cv, a.flip_x, a.flip_y, a.invert))
    cv = new(); cv.rect(0, 0, W // 2, H)
    save('A4_bord_net_vertical', 'A', 'moitié gauche blanche, bord vertical au centre (flou de bord)', finish(cv, a.flip_x, a.flip_y, a.invert))
    cv = new(); cv.rect(0, 0, W, H // 2)
    save('A4_bord_net_horizontal', 'A', 'moitié haute blanche, bord horizontal au centre (flou de bord)', finish(cv, a.flip_x, a.flip_y, a.invert))
    # --- Banc B ---
    for n, label in [(5, '5px'), (10, '10px'), (max(1, round(500 / p)), '0p5mm')]:
        cv = new(); cv.square_c(W // 2, H // 2, n)
        save('B_bloc_' + label, 'B', 'carré blanc de %d x %d pixels (%.0f µm) au centre' % (n, n, n * p), finish(cv, a.flip_x, a.flip_y, a.invert))
    # --- Banc C ---
    n2 = max(1, round(2000 / p)); n3 = max(1, round(3000 / p))
    cv = new(); cv.square_c(W // 2, H // 2, n2)
    save('C1_carre_2mm_centre', 'C1', 'carré blanc de %d pixels (2 mm) au centre' % n2, finish(cv, a.flip_x, a.flip_y, a.invert))
    cv = new(); cv.square_c(int(0.1 * W), int(0.1 * H), n2)
    save('C1_carre_2mm_coin', 'C1', 'carré blanc de %d pixels (2 mm) près d\'un coin (variation du flou)' % n2, finish(cv, a.flip_x, a.flip_y, a.invert))
    cv = new(); cv.square_c(W // 2, H // 2, n3)
    save('C2_carre_3mm', 'C2', 'carré blanc de %d pixels (3 mm) au centre (balayage angulaire)' % n3, finish(cv, a.flip_x, a.flip_y, a.invert))
    # --- Banc D ---
    cv = new(); cv.rect(0, 0, W, H)
    save('D_tout_blanc', 'D', 'écran entièrement blanc (éclairement)', finish(cv, a.flip_x, a.flip_y, a.invert))
    save('D_tout_noir', 'D', 'écran entièrement noir (fuite de lumière)', finish(new(), False, False, a.invert))
    # --- Banc E ---
    cv = new(); plate(cv, W, H)
    save('E_plaque_essai_100x60mm', 'E', 'plaque d\'essai 100 x 60 mm : lignes, paires, carrés, disque, barre', finish(cv, a.flip_x, a.flip_y, a.invert))

    with open(os.path.join(a.out, 'motifs.csv'), 'w', newline='', encoding='utf-8') as fh:
        wr = csv.writer(fh)
        wr.writerow(['fichier', 'banc', 'description'])
        wr.writerows(rows)
        wr.writerow([])
        wr.writerow(['résolution', '%d x %d' % (W, H)])
        wr.writerow(['pas (µm)', p])
        wr.writerow(['miroir x / y / inversé', '%s / %s / %s' % (a.flip_x, a.flip_y, a.invert)])
    print('terminé :', len(rows), 'images dans', a.out)


if __name__ == '__main__':
    main()
